import React, { useState } from 'react';
import { Grid, Paper, TextField, Button, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Box, Tabs, Tab, Zoom, Fade } from '@mui/material';
import { NumericFormat } from 'react-number-format';

const IncomeTaxCalculator = () => {
  const [inputs, setInputs] = useState({
    totalEarnings: '1500000',
    hraPaid: '120000',
    section80C: '150000',
    housingLoan: '',
    chapterVIOthers: '',
    otherIncome: '',
    fbp: ''
  });

  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (values, name) => {
    setInputs(prev => ({
      ...prev,
      [name]: values.floatValue || ''
    }));
  };

  const calculateMockTax = () => {
    return {
      oldRegime: {
        totalTaxWithCess: 163800,
        grossIncome: 1500000,
        totalDeductions: 395000,
        taxableIncome: 1105000,
        taxSlabs: [
          { range: 'Up to ₹2,50,000', tax: 0 },
          { range: '₹2,50,001 - ₹5,00,000', tax: 12500 },
          { range: '₹5,00,001 - ₹10,00,000', tax: 100000 },
          { range: 'Above ₹10,00,000', tax: 31500 }
        ],
        cess: 6300
      },
      newRegime: {
        totalTaxWithCess: 187200,
        grossIncome: 1500000,
        standardDeduction: 50000,
        taxableIncome: 1450000,
        taxSlabs: [
          { range: 'Up to ₹3,00,000', tax: 0 },
          { range: '₹3,00,001 - ₹6,00,000', tax: 15000 },
          { range: '₹6,00,001 - ₹9,00,000', tax: 30000 },
          { range: '₹9,00,001 - ₹12,00,000', tax: 60000 },
          { range: 'Above ₹12,00,000', tax: 75000 }
        ],
        cess: 7200
      },
      suggestion: 'old',
      savings: 23400
    };
  };

  const handleCalculate = () => {
    const mockResults = calculateMockTax();
    setResults(mockResults);
  };

  const inputFields = [
    { label: 'Total Earnings', name: 'totalEarnings' },
    { label: 'HRA Paid', name: 'hraPaid' },
    { label: '80C Deductions', name: 'section80C' },
    { label: 'Housing Loan', name: 'housingLoan' },
    { label: 'Chapter VI Others', name: 'chapterVIOthers' },
    { label: 'Other Income', name: 'otherIncome' },
    { label: 'FBP', name: 'fbp' }
  ];

  // Color scheme
  const colors = {
    primary: '#4a148c',
    secondary: '#ff6f00',
    background: '#f5f5f5',
    highlight: '#e3f2fd',
    success: '#2e7d32',
    text: '#212121'
  };

  return (
    <div style={{ 
      display: 'flex',
      height: '100vh',
      padding: '20px',
      boxSizing: 'border-box',
      backgroundColor: colors.background
    }}>
      {/* Left Panel - Input Form */}
      <Paper elevation={3} style={{
        width: '50%',
        padding: '25px',
        marginRight: '15px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px'
      }}>
        <Typography variant="h5" gutterBottom style={{ 
          marginBottom: '25px',
          color: colors.primary,
          fontWeight: '600'
        }}>
          Enter Your Details
        </Typography>
        
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          indicatorColor="secondary"
          textColor="secondary"
        >
          {inputFields.map((field, index) => (
            <Tab 
              key={index} 
              label={field.label} 
              style={{
                fontWeight: activeTab === index ? '600' : '400',
                color: activeTab === index ? colors.secondary : colors.text
              }}
            />
          ))}
        </Tabs>
        
        <Box mt={3}>
          <NumericFormat
            customInput={TextField}
            fullWidth
            label={`${inputFields[activeTab].label} (₹)`}
            variant="outlined"
            name={inputFields[activeTab].name}
            value={inputs[inputFields[activeTab].name]}
            onValueChange={(values) => handleInputChange(values, inputFields[activeTab].name)}
            thousandSeparator={true}
            InputLabelProps={{ shrink: true }}
            style={{ marginBottom: '20px' }}
            InputProps={{
              style: {
                fontSize: '16px',
                backgroundColor: '#fff'
              }
            }}
          />
        </Box>
        
        <Box mt={2} p={3} bgcolor={colors.highlight} borderRadius="8px">
          <Typography variant="subtitle2" style={{ 
            fontWeight: '600',
            color: colors.primary,
            marginBottom: '10px'
          }}>
            All Input Values:
          </Typography>
          {inputFields.map((field, index) => (
            <Typography key={index} variant="body2" style={{ marginBottom: '5px' }}>
              <strong style={{ color: colors.text }}>{field.label}:</strong> 
              <span style={{ 
                color: inputs[field.name] ? colors.primary : '#9e9e9e',
                marginLeft: '5px'
              }}>
                {inputs[field.name] ? `₹${Number(inputs[field.name]).toLocaleString('en-IN')}` : 'Not entered'}
              </span>
            </Typography>
          ))}
        </Box>
        
        <Box mt={4} display="flex" justifyContent="center">
          <Button 
            variant="contained" 
            color="primary" 
            onClick={handleCalculate}
            size="large"
            style={{ 
              padding: '12px 36px',
              fontSize: '16px',
              fontWeight: 'bold',
              borderRadius: '8px',
              textTransform: 'none',
              backgroundColor: colors.secondary,
              color: '#fff',
              boxShadow: '0 3px 5px rgba(0,0,0,0.2)',
              '&:hover': {
                backgroundColor: '#e65100'
              }
            }}
          >
            CALCULATE TAX
          </Button>
        </Box>
      </Paper>

      {/* Right Panel - Results */}
      <Paper elevation={3} style={{
        width: '50%',
        padding: '25px',
        marginLeft: '15px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px'
      }}>
        {results ? (
          <>
            <Typography variant="h5" gutterBottom style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '25px'
            }}>
              Tax Calculation Results
            </Typography>
            
            <Box mb={4} p={3} bgcolor={colors.highlight} borderRadius="8px">
              <Typography variant="h6" style={{ 
                color: colors.primary,
                fontWeight: '600',
                marginBottom: '15px'
              }}>
                Tax Regime Comparison
              </Typography>
              <Grid container spacing={3} style={{ marginTop: '10px' }}>
                <Grid item xs={6}>
                  <Zoom in={true} style={{ transitionDelay: results.suggestion === 'old' ? '100ms' : '0ms' }}>
                    <Box 
                      p={3}
                      bgcolor={results.suggestion === 'old' ? '#e8f5e9' : '#ffffff'}
                      border={results.suggestion === 'old' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                      borderRadius="8px"
                      textAlign="center"
                      style={{
                        transition: 'all 0.3s ease',
                        transform: results.suggestion === 'old' ? 'scale(1.02)' : 'scale(1)',
                        boxShadow: results.suggestion === 'old' ? `0 4px 8px rgba(46, 125, 50, 0.2)` : 'none'
                      }}
                    >
                      <Typography style={{ fontWeight: '600' }}>Old Regime</Typography>
                      <Typography variant="h4" style={{ 
                        margin: '12px 0',
                        fontWeight: '700',
                        color: results.suggestion === 'old' ? colors.success : colors.text
                      }}>
                        ₹{results.oldRegime.totalTaxWithCess.toLocaleString('en-IN')}
                      </Typography>
                    </Box>
                  </Zoom>
                </Grid>
                <Grid item xs={6}>
                  <Zoom in={true} style={{ transitionDelay: results.suggestion === 'new' ? '100ms' : '0ms' }}>
                    <Box 
                      p={3}
                      bgcolor={results.suggestion === 'new' ? '#e8f5e9' : '#ffffff'}
                      border={results.suggestion === 'new' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                      borderRadius="8px"
                      textAlign="center"
                      style={{
                        transition: 'all 0.3s ease',
                        transform: results.suggestion === 'new' ? 'scale(1.02)' : 'scale(1)',
                        boxShadow: results.suggestion === 'new' ? `0 4px 8px rgba(46, 125, 50, 0.2)` : 'none'
                      }}
                    >
                      <Typography style={{ fontWeight: '600' }}>New Regime</Typography>
                      <Typography variant="h4" style={{ 
                        margin: '12px 0',
                        fontWeight: '700',
                        color: results.suggestion === 'new' ? colors.success : colors.text
                      }}>
                        ₹{results.newRegime.totalTaxWithCess.toLocaleString('en-IN')}
                      </Typography>
                    </Box>
                  </Zoom>
                </Grid>
              </Grid>
              <Fade in={true} timeout={500}>
                <Box mt={3} textAlign="center">
                  <Typography variant="h6" style={{ 
                    color: colors.success,
                    fontWeight: '600',
                    margin: '15px 0'
                  }}>
                    Better by ₹{results.savings.toLocaleString('en-IN')}
                  </Typography>
                  <Typography style={{ fontWeight: '500' }}>
                    <strong>Recommendation:</strong> The <span style={{ 
                      color: colors.success,
                      fontWeight: '600'
                    }}>{results.suggestion}</span> tax regime is better for you.
                  </Typography>
                </Box>
              </Fade>
            </Box>
            
            <Typography variant="h6" style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '15px'
            }}>
              Detailed Tax Breakdown
            </Typography>
            <Grid container spacing={3}>
              <Grid item xs={6}>
                <Fade in={true} timeout={800}>
                  <TableContainer component={Paper} elevation={2} style={{ borderRadius: '8px' }}>
                    <Table size="small">
                      <TableHead style={{ backgroundColor: colors.highlight }}>
                        <TableRow>
                          <TableCell style={{ fontWeight: '600' }}>Old Regime</TableCell>
                          <TableCell align="right" style={{ fontWeight: '600' }}>Amount (₹)</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {results.oldRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`old-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Fade>
              </Grid>
              <Grid item xs={6}>
                <Fade in={true} timeout={1000}>
                  <TableContainer component={Paper} elevation={2} style={{ borderRadius: '8px' }}>
                    <Table size="small">
                      <TableHead style={{ backgroundColor: colors.highlight }}>
                        <TableRow>
                          <TableCell style={{ fontWeight: '600' }}>New Regime</TableCell>
                          <TableCell align="right" style={{ fontWeight: '600' }}>Amount (₹)</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {results.newRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`new-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Fade>
              </Grid>
            </Grid>
          </>
        ) : (
          <Fade in={true} timeout={500}>
            <Box 
              display="flex" 
              alignItems="center" 
              justifyContent="center" 
              height="100%"
              textAlign="center"
            >
              <Typography variant="body1" style={{ color: '#9e9e9e' }}>
                Enter your details and click "CALCULATE TAX" to see results
              </Typography>
            </Box>
          </Fade>
        )}
      </Paper>
    </div>
  );
};

export default IncomeTaxCalculator;