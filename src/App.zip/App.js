import React, { useState } from 'react';
import { Box, Tab, Tabs, Paper, Button, Grid, Typography } from '@mui/material';
import InputTab from './components/InputTab';
import ResultDisplay from './components/ResultDisplay';
import { calculateTax } from './services/taxService';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState(0);
  const [inputs, setInputs] = useState({
    totalEarnings: 0,
    hraPaid: 0,
    section80C: 0,
    housingLoan: 0,
    chapterVIOthers: 0,
    otherIncome: 0,
    fbp: 0
  });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (name, value) => {
    setInputs(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0
    }));
  };

  const handleCalculate = async () => {
    setLoading(true);
    try {
      const taxData = await calculateTax(inputs);
      setResults(taxData);
    } catch (error) {
      console.error("Error calculating tax:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <Typography variant="h4" gutterBottom style={{ margin: '20px 0', color: '#2c3e50' }}>
        Income Tax Calculator
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} style={{ padding: '20px' }}>
            <Tabs value={activeTab} onChange={handleTabChange} variant="scrollable">
              <Tab label="Total Earnings" />
              <Tab label="HRA Paid" />
              <Tab label="80C Deductions" />
              <Tab label="Housing Loan" />
              <Tab label="Chapter VI Others" />
              <Tab label="Other Income" />
              <Tab label="FBP" />
            </Tabs>
            <Box mt={3}>
              <InputTab 
                activeTab={activeTab} 
                inputs={inputs} 
                onInputChange={handleInputChange} 
              />
            </Box>
            <Box mt={3} display="flex" justifyContent="center">
              <Button 
                variant="contained" 
                color="primary" 
                onClick={handleCalculate}
                disabled={loading}
              >
                {loading ? 'Calculating...' : 'Calculate Tax'}
              </Button>
            </Box>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <ResultDisplay results={results} />
        </Grid>
      </Grid>
    </div>
  );
}

export default App;