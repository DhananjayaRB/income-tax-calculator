import React, { useState } from 'react';
import { 
  Paper, TextField, Button, Typography, Table, TableBody, 
  TableCell, TableContainer, TableHead, TableRow, Box, 
  Tabs, Tab, Grow, Fade, Slide, CircularProgress, Alert 
} from '@mui/material';
import { NumericFormat } from 'react-number-format';
import { keyframes } from '@emotion/react';
import axios from 'axios';

// Custom pulse animation
const pulse = keyframes`
  0% { transform: scale(1); box-shadow: 0 0 0 rgba(46, 125, 50, 0.4); }
  70% { transform: scale(1.03); box-shadow: 0 0 10px rgba(46, 125, 50, 0.6); }
  100% { transform: scale(1); box-shadow: 0 0 0 rgba(46, 125, 50, 0.4); }
`;

// API configuration
const API_BASE_URL = 'https://uat-api.resolveindia.com/payrun'; // Replace with your actual API endpoint
const API_ENDPOINT = '/income-tax';

const IncomeTaxCalculator = () => {
  const [inputs, setInputs] = useState({
    totalEarnings: '',
    hraPaid: '',
    section80C: '',
    housingLoan: '',
    chapterVIOthers: '',
    otherIncome: '',
    fbp: ''
  });

  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (values, name) => {
    setInputs(prev => ({
      ...prev,
      [name]: values.floatValue || ''
    }));
  };

  const calculateTax = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Prepare request payload
      const payload = {
        financialYear: '2025-2026', // You can make this dynamic
        incomeDetails: {
          ...inputs,
          // Convert empty strings to 0
          totalEarnings: inputs.totalEarnings || 0,
          hraPaid: inputs.hraPaid || 0,
          section80C: inputs.section80C || 0,
          housingLoan: inputs.housingLoan || 0,
          chapterVIOthers: inputs.chapterVIOthers || 0,
          otherIncome: inputs.otherIncome || 0,
          fbp: inputs.fbp || 0
        }
      };

      // Make API call
      const response = await axios.post(`${API_BASE_URL}${API_ENDPOINT}`, payload, {
        headers: {
          'Content-Type': 'application/json',
          // Add authentication headers if needed
          // 'Authorization': `Bearer ${yourAuthToken}`
        }
      });

      // Process API response
      if (response.data && response.data.success) {
        setResults(response.data.data);
      } else {
        throw new Error(response.data?.message || 'Invalid response from server');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to calculate tax');
      console.error('Tax calculation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const inputFields = [
    { label: 'Total Earnings', name: 'totalEarnings' },
    { label: 'HRA Paid', name: 'hraPaid' },
    { label: '80C Deductions', name: 'section80C' },
    { label: 'Housing Loan', name: 'housingLoan' },
    { label: 'Chapter VI Others', name: 'chapterVIOthers' },
    { label: 'Other Income', name: 'otherIncome' },
    { label: 'FBP', name: 'fbp' }
  ];

  // Color scheme
  const colors = {
    primary: '#028CA3',
    secondary: '#028CA3',
    background: '#f5f5f5',
    highlight: '#e3f2fd',
    success: '#028CA3',
    text: '#212121'
  };

  return (
    <div style={{ 
      display: 'flex',
      height: '100vh',
      padding: '20px',
      boxSizing: 'border-box',
      backgroundColor: colors.background,
      gap: '20px'
    }}>
      {/* Left Panel - Input Form (70%) */}
      <Paper elevation={3} style={{
        width: '70%',
        padding: '25px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        transition: 'all 0.3s ease'
      }}>
        <Typography variant="h5" gutterBottom style={{ 
          marginBottom: '25px',
          color: colors.primary,
          fontWeight: '600'
        }}>
          Enter Your Details
        </Typography>
        
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          indicatorColor="secondary"
          textColor="secondary"
        >
          {inputFields.map((field, index) => (
            <Tab 
              key={index} 
              label={field.label} 
              style={{
                fontWeight: activeTab === index ? '600' : '400',
                color: activeTab === index ? colors.secondary : colors.text,
                fontSize: '0.9rem'
              }}
            />
          ))}
        </Tabs>
        
        <Box mt={3}>
          <NumericFormat
            customInput={TextField}
            fullWidth
            label={`${inputFields[activeTab].label} (₹)`}
            variant="outlined"
            name={inputFields[activeTab].name}
            value={inputs[inputFields[activeTab].name]}
            onValueChange={(values) => handleInputChange(values, inputFields[activeTab].name)}
            thousandSeparator={true}
            InputLabelProps={{ shrink: true }}
            style={{ marginBottom: '20px' }}
            InputProps={{
              style: {
                fontSize: '16px',
                backgroundColor: '#fff'
              }
            }}
          />
        </Box>
        
        <Box mt={2} p={3} bgcolor={colors.highlight} borderRadius="8px">
          <Typography variant="subtitle2" style={{ 
            fontWeight: '600',
            color: colors.primary,
            marginBottom: '10px'
          }}>
            All Input Values:
          </Typography>
          <Box display="grid" gridTemplateColumns="repeat(2, 1fr)" gap={1}>
            {inputFields.map((field, index) => (
              <Box key={index}>
                <Typography variant="body2" style={{ marginBottom: '5px' }}>
                  <strong style={{ color: colors.text }}>{field.label}:</strong> 
                  <span style={{ 
                    color: inputs[field.name] ? colors.primary : '#9e9e9e',
                    marginLeft: '5px'
                  }}>
                    {inputs[field.name] ? `₹${Number(inputs[field.name]).toLocaleString('en-IN')}` : 'Not entered'}
                  </span>
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
        
        <Box mt={4} display="flex" justifyContent="center">
          <Button 
            variant="contained" 
            onClick={calculateTax}
            size="large"
            disabled={loading}
            style={{ 
              padding: '12px 36px',
              fontSize: '16px',
              fontWeight: 'bold',
              borderRadius: '8px',
              textTransform: 'none',
              backgroundColor: colors.secondary,
              color: '#fff',
              boxShadow: '0 3px 5px rgba(0,0,0,0.2)',
              minWidth: '200px',
              '&:hover': {
                backgroundColor: '#e65100'
              }
            }}
          >
            {loading ? (
              <>
                <CircularProgress size={24} style={{ color: '#fff', marginRight: '8px' }} />
                Calculating...
              </>
            ) : 'CALCULATE TAX'}
          </Button>
        </Box>

        {error && (
          <Box mt={2}>
            <Alert severity="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          </Box>
        )}
      </Paper>

      {/* Right Panel - Results (30%) */}
      <Paper elevation={3} style={{
        width: '30%',
        padding: '25px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {loading ? (
          <Box 
            display="flex" 
            flexDirection="column"
            alignItems="center" 
            justifyContent="center" 
            height="100%"
            gap={2}
          >
            <CircularProgress size={60} style={{ color: colors.secondary }} />
            <Typography variant="body1" style={{ color: colors.secondary }}>
              Calculating your tax savings...
            </Typography>
          </Box>
        ) : results ? (
          <>
            <Typography variant="h5" gutterBottom style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '25px'
            }}>
              Tax Results
            </Typography>
            
            <Box mb={4} p={3} bgcolor={colors.highlight} borderRadius="8px">
              <Typography variant="h6" style={{ 
                color: colors.primary,
                fontWeight: '600',
                marginBottom: '15px'
              }}>
                Tax Regime Comparison
              </Typography>
              
              <Box mb={2}>
                <Grow in={true} timeout={500}>
                  <Box 
                    p={3}
                    bgcolor={results.suggestion === 'OLD' ? '#84D4DE' : '#ffffff'}
                    border={results.suggestion === 'OLD' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                    borderRadius="8px"
                    textAlign="center"
                    sx={results.suggestion === 'OLD' ? {
                      animation: `${pulse} 1.5s ease-in-out 2`,
                      transform: 'scale(1.02)'
                    } : {}}
                  >
                    <Typography style={{ fontWeight: '600' }}>Old Regime</Typography>
                    <Typography variant="h5" style={{ 
                      margin: '12px 0',
                      fontWeight: '700',
                      color: results.suggestion === 'OLD' ? colors.success : colors.text
                    }}>
                      ₹{results.oldRegime.totalTaxWithCess.toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Grow>
              </Box>
              
              <Box mt={2}>
                <Grow in={true} timeout={700}>
                  <Box 
                    p={3}
                    bgcolor={results.suggestion === 'NEW' ? '#84D4DE' : '#ffffff'}
                    border={results.suggestion === 'NEW' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                    borderRadius="8px"
                    textAlign="center"
                    sx={results.suggestion === 'NEW' ? {
                      animation: `${pulse} 1.5s ease-in-out 2`,
                      transform: 'scale(1.02)'
                    } : {}}
                  >
                    <Typography style={{ fontWeight: '600' }}>New Regime</Typography>
                    <Typography variant="h5" style={{ 
                      margin: '12px 0',
                      fontWeight: '700',
                      color: results.suggestion === 'NEW' ? colors.success : colors.text
                    }}>
                      ₹{results.newRegime.totalTaxWithCess.toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Grow>
              </Box>
              
              <Slide direction="up" in={true} timeout={1000}>
                <Box mt={3} textAlign="center">
                  <Typography variant="h6" style={{ 
                    color: colors.success,
                    fontWeight: '600',
                    margin: '15px 0'
                  }}>
                    Better by ₹{results.savings.toLocaleString('en-IN')}
                  </Typography>
                  <Typography style={{ fontWeight: '500' }}>
                    <strong>Recommendation:</strong> The <span style={{ 
                      color: colors.success,
                      fontWeight: '600'
                    }}>{results.suggestion}</span> tax regime is better for you.
                  </Typography>
                </Box>
              </Slide>
            </Box>
            
            <Typography variant="h6" style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '15px'
            }}>
              Tax Breakdown
            </Typography>
            
            <Box sx={{ overflow: 'auto', maxHeight: '300px' }}>
              <Fade in={true} timeout={1200}>
                <TableContainer component={Paper} elevation={2} style={{ borderRadius: '8px' }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell style={{ fontWeight: '600' }}>Component</TableCell>
                        <TableCell align="right" style={{ fontWeight: '600' }}>Amount (₹)</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {results.suggestion === 'old' ? (
                        results.oldRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`old-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        results.newRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`new-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Fade>
            </Box>
          </>
        ) : (
          <Fade in={true} timeout={500}>
            <Box 
              display="flex" 
              alignItems="center" 
              justifyContent="center" 
              height="100%"
              textAlign="center"
            >
              <Typography variant="body1" style={{ color: '#9e9e9e' }}>
                Enter details and click "CALCULATE TAX" to see results
              </Typography>
            </Box>
          </Fade>
        )}
      </Paper>
    </div>
  );
};

export default IncomeTaxCalculator;