import React, { useState } from 'react';
import { Grid } from '@mui/material';

import { 
  Paper, TextField, Button, Typography, Table, TableBody, 
  TableCell, TableContainer, TableHead, TableRow, Box, 
  Tabs, Tab, Grow, Fade, Slide 
} from '@mui/material';
import { NumericFormat } from 'react-number-format';
import { keyframes } from '@emotion/react';

// Custom pulse animation
const pulse = keyframes`
  0% { transform: scale(1); box-shadow: 0 0 0 rgba(46, 125, 50, 0.4); }
  70% { transform: scale(1.03); box-shadow: 0 0 10px rgba(46, 125, 50, 0.6); }
  100% { transform: scale(1); box-shadow: 0 0 0 rgba(46, 125, 50, 0.4); }
`;

const IncomeTaxCalculator = () => {
  const [inputs, setInputs] = useState({
    totalEarnings: '1500000',
    hraPaid: '120000',
    section80C: '150000',
    housingLoan: '',
    chapterVIOthers: '',
    otherIncome: '',
    fbp: ''
  });

  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [calculating, setCalculating] = useState(false);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (values, name) => {
    setInputs(prev => ({
      ...prev,
      [name]: values.floatValue || ''
    }));
  };

  const calculateMockTax = () => {
    return {
      oldRegime: {
        totalTaxWithCess: 163800,
        grossIncome: 1500000,
        totalDeductions: 395000,
        taxableIncome: 1105000,
        taxSlabs: [
          { range: 'Up to ₹2,50,000', tax: 0 },
          { range: '₹2,50,001 - ₹5,00,000', tax: 12500 },
          { range: '₹5,00,001 - ₹10,00,000', tax: 100000 },
          { range: 'Above ₹10,00,000', tax: 31500 }
        ],
        cess: 6300
      },
      newRegime: {
        totalTaxWithCess: 187200,
        grossIncome: 1500000,
        standardDeduction: 50000,
        taxableIncome: 1450000,
        taxSlabs: [
          { range: 'Up to ₹3,00,000', tax: 0 },
          { range: '₹3,00,001 - ₹6,00,000', tax: 15000 },
          { range: '₹6,00,001 - ₹9,00,000', tax: 30000 },
          { range: '₹9,00,001 - ₹12,00,000', tax: 60000 },
          { range: 'Above ₹12,00,000', tax: 75000 }
        ],
        cess: 7200
      },
      suggestion: 'old',
      savings: 23400
    };
  };

  const handleCalculate = () => {
    setCalculating(true);
    setTimeout(() => {
      const mockResults = calculateMockTax();
      setResults(mockResults);
      setCalculating(false);
    }, 800);
  };

  const inputFields = [
    { label: 'Total Earnings', name: 'totalEarnings' },
    { label: 'HRA Paid', name: 'hraPaid' },
    { label: '80C Deductions', name: 'section80C' },
    { label: 'Housing Loan', name: 'housingLoan' },
    { label: 'Chapter VI Others', name: 'chapterVIOthers' },
    { label: 'Other Income', name: 'otherIncome' },
    { label: 'FBP', name: 'fbp' }
  ];

  // Color scheme
  const colors = {
    primary: '#028CA3',
    secondary: '#028CA3',
    background: '#f5f5f5',
    highlight: '#e3f2fd',
    success: '#028CA3',
    text: '#212121'
  };

  return (
    <div style={{ 
      display: 'flex',
      height: '100vh',
      padding: '20px',
      boxSizing: 'border-box',
      backgroundColor: colors.background,
      gap: '20px'
    }}>
      {/* Left Panel - Input Form (70%) */}
      <Paper elevation={3} style={{
        width: '70%',
        padding: '25px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        transition: 'all 0.3s ease'
      }}>
        <Typography variant="h5" gutterBottom style={{ 
          marginBottom: '25px',
          color: colors.primary,
          fontWeight: '600'
        }}>
          Enter Your Salary Details
        </Typography>
        
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
          indicatorColor="secondary"
          textColor="secondary"
        >
          {inputFields.map((field, index) => (
            <Tab 
              key={index} 
              label={field.label} 
              style={{
                fontWeight: activeTab === index ? '600' : '400',
                color: activeTab === index ? colors.secondary : colors.text,
                fontSize: '0.9rem'
              }}
            />
          ))}
        </Tabs>
        
        <Box mt={3}>
          <NumericFormat
            customInput={TextField}
            fullWidth
            label={`${inputFields[activeTab].label} (₹)`}
            variant="outlined"
            name={inputFields[activeTab].name}
            value={inputs[inputFields[activeTab].name]}
            onValueChange={(values) => handleInputChange(values, inputFields[activeTab].name)}
            thousandSeparator={true}
            InputLabelProps={{ shrink: true }}
            style={{ marginBottom: '20px' }}
            InputProps={{
              style: {
                fontSize: '16px',
                backgroundColor: '#fff'
              }
            }}
          />
        </Box>
        
        <Box mt={2} p={3} bgcolor={colors.highlight} borderRadius="8px">
          <Typography variant="subtitle2" style={{ 
            fontWeight: '600',
            color: colors.primary,
            marginBottom: '10px'
          }}>
            All Input Values:
          </Typography>
          <Grid container spacing={1}>
            {inputFields.map((field, index) => (
              <Grid item xs={6} key={index}>
                <Typography variant="body2" style={{ marginBottom: '5px' }}>
                  <strong style={{ color: colors.text }}>{field.label}:</strong> 
                  <span style={{ 
                    color: inputs[field.name] ? colors.primary : '#9e9e9e',
                    marginLeft: '5px'
                  }}>
                    {inputs[field.name] ? `₹${Number(inputs[field.name]).toLocaleString('en-IN')}` : 'Not entered'}
                  </span>
                </Typography>
              </Grid>
            ))}
          </Grid>
        </Box>
        
        <Box mt={4} display="flex" justifyContent="center">
          <Button 
            variant="contained" 
            onClick={handleCalculate}
            size="large"
            disabled={calculating}
            style={{ 
              padding: '12px 36px',
              fontSize: '16px',
              fontWeight: 'bold',
              borderRadius: '8px',
              textTransform: 'none',
              backgroundColor: colors.secondary,
              color: '#fff',
              boxShadow: '0 3px 5px rgba(0,0,0,0.2)',
              minWidth: '200px'
            }}
          >
            {calculating ? 'Calculating...' : 'CALCULATE TAX'}
          </Button>
        </Box>
      </Paper>

      {/* Right Panel - Results (30%) */}
      <Paper elevation={3} style={{
        width: '30%',
        padding: '25px',
        overflowY: 'auto',
        backgroundColor: '#ffffff',
        borderRadius: '12px',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {calculating ? (
          <Box 
            display="flex" 
            alignItems="center" 
            justifyContent="center" 
            height="100%"
          >
            <Fade in={true} timeout={500}>
              <Typography variant="body1" style={{ color: colors.secondary }}>
                Calculating your tax savings...
              </Typography>
            </Fade>
          </Box>
        ) : results ? (
          <>
            <Typography variant="h5" gutterBottom style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '25px'
            }}>
              Tax Results
            </Typography>
            
            <Box mb={4} p={3} bgcolor={colors.highlight} borderRadius="8px">
              <Typography variant="h6" style={{ 
                color: colors.primary,
                fontWeight: '600',
                marginBottom: '15px'
              }}>
                Tax Regime Comparison
              </Typography>
              
              <Box mb={2}>
                <Grow in={true} timeout={500}>
                  <Box 
                    p={3}
                    bgcolor={results.suggestion === 'old' ? '#84D4DE' : '#ffffff'}
                    border={results.suggestion === 'old' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                    borderRadius="8px"
                    textAlign="center"
                    sx={results.suggestion === 'old' ? {
                      animation: `${pulse} 1.5s ease-in-out 2`,
                      transform: 'scale(1.02)'
                    } : {}}
                  >
                    <Typography style={{ fontWeight: '600' }}>Old Regime</Typography>
                    <Typography variant="h5" style={{ 
                      margin: '12px 0',
                      fontWeight: '700',
                      color: results.suggestion === 'old' ? colors.success : colors.text
                    }}>
                      ₹{results.oldRegime.totalTaxWithCess.toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Grow>
              </Box>
              
              <Box mt={2}>
                <Grow in={true} timeout={700}>
                  <Box 
                    p={3}
                    bgcolor={results.suggestion === 'new' ? '#84D4DE' : '#ffffff'}
                    border={results.suggestion === 'new' ? `2px solid ${colors.success}` : '1px solid #e0e0e0'}
                    borderRadius="8px"
                    textAlign="center"
                    sx={results.suggestion === 'new' ? {
                      animation: `${pulse} 1.5s ease-in-out 2`,
                      transform: 'scale(1.02)'
                    } : {}}
                  >
                    <Typography style={{ fontWeight: '600' }}>New Regime</Typography>
                    <Typography variant="h5" style={{ 
                      margin: '12px 0',
                      fontWeight: '700',
                      color: results.suggestion === 'new' ? colors.success : colors.text
                    }}>
                      ₹{results.newRegime.totalTaxWithCess.toLocaleString('en-IN')}
                    </Typography>
                  </Box>
                </Grow>
              </Box>
              
              <Slide direction="up" in={true} timeout={1000}>
                <Box mt={3} textAlign="center">
                  <Typography variant="h6" style={{ 
                    color: colors.success,
                    fontWeight: '600',
                    margin: '15px 0'
                  }}>
                    Better by ₹{results.savings.toLocaleString('en-IN')}
                  </Typography>
                  <Typography style={{ fontWeight: '500' }}>
                    <strong>Recommendation:</strong> The <span style={{ 
                      color: colors.success,
                      fontWeight: '600'
                    }}>{results.suggestion}</span> tax regime is better for you.
                  </Typography>
                </Box>
              </Slide>
            </Box>
            
            <Typography variant="h6" style={{ 
              color: colors.primary,
              fontWeight: '600',
              marginBottom: '15px'
            }}>
              Tax Breakdown
            </Typography>
            
            <Box sx={{ overflow: 'auto', maxHeight: '300px' }}>
              <Fade in={true} timeout={1200}>
                <TableContainer component={Paper} elevation={2} style={{ borderRadius: '8px' }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell style={{ fontWeight: '600' }}>Component</TableCell>
                        <TableCell align="right" style={{ fontWeight: '600' }}>Amount (₹)</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {results.suggestion === 'old' ? (
                        results.oldRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`old-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        results.newRegime.taxSlabs.map((slab, index) => (
                          <TableRow key={`new-${index}`} hover>
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax.toLocaleString('en-IN')}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Fade>
            </Box>
          </>
        ) : (
          <Fade in={true} timeout={500}>
            <Box 
              display="flex" 
              alignItems="center" 
              justifyContent="center" 
              height="100%"
              textAlign="center"
            >
              <Typography variant="body1" style={{ color: '#9e9e9e' }}>
                Enter details and click "CALCULATE TAX" to see results
              </Typography>
            </Box>
          </Fade>
        )}
      </Paper>
    </div>
  );
};

export default IncomeTaxCalculator;