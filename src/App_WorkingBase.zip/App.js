import React, { useState } from 'react';
import { Grid, Paper, TextField, Button, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Box, Tabs, Tab } from '@mui/material';

const IncomeTaxCalculator = () => {
  const [inputs, setInputs] = useState({
    totalEarnings: '1500000',
    hraPaid: '120000',
    section80C: '150000',
    housingLoan: '',
    chapterVIOthers: '',
    otherIncome: '',
    fbp: ''
  });

  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputs(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const calculateMockTax = () => {
    return {
      oldRegime: {
        totalTaxWithCess: 163800,
        grossIncome: 1500000,
        totalDeductions: 395000,
        taxableIncome: 1105000,
        taxSlabs: [
          { range: 'Up to ₹2,50,000', tax: 0 },
          { range: '₹2,50,001 - ₹5,00,000', tax: 12500 },
          { range: '₹5,00,001 - ₹10,00,000', tax: 100000 },
          { range: 'Above ₹10,00,000', tax: 31500 }
        ],
        cess: 6300
      },
      newRegime: {
        totalTaxWithCess: 187200,
        grossIncome: 1500000,
        standardDeduction: 50000,
        taxableIncome: 1450000,
        taxSlabs: [
          { range: 'Up to ₹3,00,000', tax: 0 },
          { range: '₹3,00,001 - ₹6,00,000', tax: 15000 },
          { range: '₹6,00,001 - ₹9,00,000', tax: 30000 },
          { range: '₹9,00,001 - ₹12,00,000', tax: 60000 },
          { range: 'Above ₹12,00,000', tax: 75000 }
        ],
        cess: 7200
      },
      suggestion: 'old',
      savings: 23400
    };
  };

  const handleCalculate = () => {
    const mockResults = calculateMockTax();
    setResults(mockResults);
  };

  const inputFields = [
    { label: 'Total Earnings', name: 'totalEarnings' },
    { label: 'HRA Paid', name: 'hraPaid' },
    { label: '80C Deductions', name: 'section80C' },
    { label: 'Housing Loan', name: 'housingLoan' },
    { label: 'Chapter VI Others', name: 'chapterVIOthers' },
    { label: 'Other Income', name: 'otherIncome' },
    { label: 'FBP', name: 'fbp' }
  ];

  return (
    <div style={{ 
      display: 'flex',
      height: '100vh',
      padding: '20px',
      boxSizing: 'border-box'
    }}>
      {/* Left Panel - Input Form */}
      <Paper elevation={3} style={{
        width: '50%',
        padding: '20px',
        marginRight: '10px',
        overflowY: 'auto'
      }}>
        <Typography variant="h5" gutterBottom style={{ marginBottom: '20px' }}>
          Enter Your Details
        </Typography>
        
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange} 
          variant="scrollable"
          scrollButtons="auto"
        >
          {inputFields.map((field, index) => (
            <Tab key={index} label={field.label} />
          ))}
        </Tabs>
        
        <Box mt={2}>
          <TextField
            fullWidth
            label={`${inputFields[activeTab].label} (₹)`}
            variant="outlined"
            name={inputFields[activeTab].name}
            value={inputs[inputFields[activeTab].name]}
            onChange={handleInputChange}
            type="number"
            InputLabelProps={{ shrink: true }}
            style={{ marginBottom: '20px' }}
          />
        </Box>
        
        <Box mt={2} p={2} bgcolor="#f5f5f5" borderRadius="4px">
          <Typography variant="subtitle2">All Input Values:</Typography>
          {inputFields.map((field, index) => (
            <Typography key={index} variant="body2">
              <strong>{field.label}:</strong> {inputs[field.name] ? `₹${parseInt(inputs[field.name]).toLocaleString()}` : 'Not entered'}
            </Typography>
          ))}
        </Box>
        
        <Box mt={3} display="flex" justifyContent="center">
          <Button 
            variant="contained" 
            color="primary" 
            onClick={handleCalculate}
            size="large"
            style={{ padding: '10px 30px' }}
          >
            CALCULATE TAX
          </Button>
        </Box>
      </Paper>

      {/* Right Panel - Results */}
      <Paper elevation={3} style={{
        width: '50%',
        padding: '20px',
        marginLeft: '10px',
        overflowY: 'auto'
      }}>
        {results ? (
          <>
            <Typography variant="h5" gutterBottom>
              Tax Calculation Results
            </Typography>
            
            <Box mb={3} p={2} bgcolor="#f5f5f5" borderRadius="4px">
              <Typography variant="h6">Tax Regime Comparison</Typography>
              <Grid container spacing={2} style={{ marginTop: '10px' }}>
                <Grid item xs={6}>
                  <Box 
                    p={2} 
                    bgcolor={results.suggestion === 'old' ? '#e8f5e9' : '#fff'} 
                    border={results.suggestion === 'old' ? '2px solid #4caf50' : '1px solid #ddd'} 
                    borderRadius="4px"
                    textAlign="center"
                  >
                    <Typography>Old Regime</Typography>
                    <Typography variant="h5">₹{results.oldRegime.totalTaxWithCess.toLocaleString()}</Typography>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box 
                    p={2} 
                    bgcolor={results.suggestion === 'new' ? '#e8f5e9' : '#fff'} 
                    border={results.suggestion === 'new' ? '2px solid #4caf50' : '1px solid #ddd'} 
                    borderRadius="4px"
                    textAlign="center"
                  >
                    <Typography>New Regime</Typography>
                    <Typography variant="h5">₹{results.newRegime.totalTaxWithCess.toLocaleString()}</Typography>
                  </Box>
                </Grid>
              </Grid>
              <Box mt={2} textAlign="center">
                <Typography color="#4caf50">
                  Better by ₹{results.savings.toLocaleString()}
                </Typography>
                <Typography>
                  <strong>Recommendation:</strong> The {results.suggestion} tax regime is better for you.
                </Typography>
              </Box>
            </Box>
            
            <Typography variant="h6">Detailed Tax Breakdown</Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TableContainer component={Paper}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>Old Regime</TableCell>
                        <TableCell align="right">Amount (₹)</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {results.oldRegime.taxSlabs.map((slab, index) => (
                        <TableRow key={`old-${index}`}>
                          <TableCell>{slab.range}</TableCell>
                          <TableCell align="right">{slab.tax.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>
              <Grid item xs={6}>
                <TableContainer component={Paper}>
                  <Table size="small">
                    <TableHead>
                      <TableRow>
                        <TableCell>New Regime</TableCell>
                        <TableCell align="right">Amount (₹)</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {results.newRegime.taxSlabs.map((slab, index) => (
                        <TableRow key={`new-${index}`}>
                          <TableCell>{slab.range}</TableCell>
                          <TableCell align="right">{slab.tax.toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Grid>
            </Grid>
          </>
        ) : (
          <Box 
            display="flex" 
            alignItems="center" 
            justifyContent="center" 
            height="100%"
          >
            <Typography>Enter details and click "CALCULATE TAX" to see results</Typography>
          </Box>
        )}
      </Paper>
    </div>
  );
};

export default IncomeTaxCalculator;