import React, { useState } from 'react';
import { Grid } from '@mui/material';
import styled from 'styled-components';

import { 
  Paper, TextField, Button, Typography, Table, TableBody, 
  TableCell, TableContainer, TableHead, TableRow, Box, 
  Tabs, Tab, Grow, Fade, Slide, CircularProgress, Alert,
  Dialog, DialogTitle, DialogContent, DialogActions, IconButton,
  useMediaQuery, useTheme
} from '@mui/material';
import { NumericFormat } from 'react-number-format';
import { keyframes } from '@emotion/react';
import axios from 'axios';
import CloseIcon from '@mui/icons-material/Close';
import ClearIcon from '@mui/icons-material/Clear';
import { motion } from 'framer-motion';

// Custom styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  borderRadius: '16px',
  boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
  transition: 'all 0.3s ease',
  overflow: 'hidden',
  '&:hover': {
    boxShadow: '0 12px 48px rgba(0, 0, 0, 0.15)'
  }
}));

const PrimaryButton = styled(Button)(({ theme }) => ({
  background: 'linear-gradient(135deg, #028CA3 0%, #025E6D 100%)',
  color: 'white',
  fontWeight: 600,
  padding: '12px 32px',
  borderRadius: '12px',
  textTransform: 'none',
  boxShadow: '0 4px 12px rgba(2, 140, 163, 0.3)',
  transition: 'all 0.3s ease',
  '&:hover': {
    transform: 'translateY(-2px)',
    boxShadow: '0 6px 16px rgba(2, 140, 163, 0.4)'
  }
}));

const SecondaryButton = styled(Button)(({ theme }) => ({
  border: '2px solid #028CA3',
  color: '#028CA3',
  fontWeight: 600,
  padding: '12px 24px',
  borderRadius: '12px',
  textTransform: 'none',
  transition: 'all 0.3s ease',
  '&:hover': {
    backgroundColor: 'rgba(2, 140, 163, 0.08)',
    border: '2px solid #028CA3'
  }
}));

// Custom animations
const fadeInUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

const pulse = keyframes`
  0% { transform: scale(1); box-shadow: 0 0 0 rgba(2, 140, 163, 0.4); }
  70% { transform: scale(1.03); box-shadow: 0 0 20px rgba(2, 140, 163, 0.6); }
  100% { transform: scale(1); box-shadow: 0 0 0 rgba(2, 140, 163, 0.4); }
`;

const API_BASE_URL = 'https://uat-api.resolveindia.com/payrun';
const API_ENDPOINT = '/income-tax';

const IncomeTaxCalculator = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const [inputs, setInputs] = useState({
    totalEarnings: '',
    hraPaid: '',
    section80C: '',
    housingLoan: '',
    chapterVIOthers: '',
    otherIncome: '',
    fbp: ''
  });

  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [openBreakup, setOpenBreakup] = useState(false);
  const [selectedRegime, setSelectedRegime] = useState(null);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleInputChange = (values, name) => {
    setInputs(prev => ({
      ...prev,
      [name]: values.floatValue || ''
    }));
  };

  const handleClear = () => {
    setInputs({
      totalEarnings: '',
      hraPaid: '',
      section80C: '',
      housingLoan: '',
      chapterVIOthers: '',
      otherIncome: '',
      fbp: ''
    });
    setResults(null);
    setError(null);
  };

  const calculateTax = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const payload = {
        financialYear: '2025-2026',
        incomeDetails: {
          ...inputs,
          totalEarnings: inputs.totalEarnings || 0,
          hraPaid: inputs.hraPaid || 0,
          section80C: inputs.section80C || 0,
          housingLoan: inputs.housingLoan || 0,
          chapterVIOthers: inputs.chapterVIOthers || 0,
          otherIncome: inputs.otherIncome || 0,
          fbp: inputs.fbp || 0
        }
      };

      const response = await axios.post(`${API_BASE_URL}${API_ENDPOINT}`, payload, {
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.data && response.data.success) {
        setResults(response.data.data);
      } else {
        throw new Error(response.data?.message || 'Invalid response from server');
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to calculate tax');
      console.error('Tax calculation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenBreakup = (regime) => {
    setSelectedRegime(regime);
    setOpenBreakup(true);
  };

  const handleCloseBreakup = () => {
    setOpenBreakup(false);
  };

  const inputFields = [
    { label: 'Total Earnings', name: 'totalEarnings' },
    { label: 'HRA Paid', name: 'hraPaid' },
    { label: '80C Deductions', name: 'section80C' },
    { label: 'Housing Loan', name: 'housingLoan' },
    { label: 'Chapter VI Others', name: 'chapterVIOthers' },
    { label: 'Other Income', name: 'otherIncome' },
    { label: 'FBP', name: 'fbp' }
  ];

  const colors = {
    primary: '#028CA3',
    secondary: '#025E6D',
    accent: '#84D4DE',
    background: '#f8fafb',
    highlight: '#e6f4f7',
    success: '#4CAF50',
    error: '#F44336',
    text: '#2d3748',
    lightText: '#718096'
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      style={{ 
        display: 'flex',
        flexDirection: isMobile ? 'column' : 'row',
        minHeight: '100vh',
        padding: isMobile ? '16px' : '24px',
        boxSizing: 'border-box',
        backgroundColor: colors.background,
        gap: '24px'
      }}
    >
      {/* Left Panel - Input Form */}
      <motion.div
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
        style={{ 
          width: isMobile ? '100%' : '70%',
          flexShrink: 0
        }}
      >
        <StyledPaper elevation={0}>
          <Box p={isMobile ? 2 : 3}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h5" style={{ 
                color: colors.primary,
                fontWeight: '700',
                letterSpacing: '-0.5px'
              }}>
                Income Tax Calculator
              </Typography>
              <Button
                variant="text"
                startIcon={<ClearIcon />}
                onClick={handleClear}
                style={{
                  color: colors.primary,
                  textTransform: 'none',
                  fontWeight: '600'
                }}
              >
                Clear All
              </Button>
            </Box>
            
            <Tabs 
              value={activeTab} 
              onChange={handleTabChange} 
              variant="scrollable"
              scrollButtons="auto"
              indicatorColor="primary"
              textColor="primary"
              sx={{
                '& .MuiTabs-indicator': {
                  height: '4px',
                  borderRadius: '4px 4px 0 0'
                }
              }}
            >
              {inputFields.map((field, index) => (
                <Tab 
                  key={index} 
                  label={field.label} 
                  sx={{
                    fontWeight: activeTab === index ? '700' : '500',
                    fontSize: '0.9rem',
                    minWidth: 'unset',
                    px: 2,
                    textTransform: 'none'
                  }}
                />
              ))}
            </Tabs>
            
            <Box mt={3}>
              <NumericFormat
                customInput={TextField}
                fullWidth
                label={`${inputFields[activeTab].label} (₹)`}
                variant="outlined"
                name={inputFields[activeTab].name}
                value={inputs[inputFields[activeTab].name]}
                onValueChange={(values) => handleInputChange(values, inputFields[activeTab].name)}
                thousandSeparator={true}
                InputLabelProps={{ 
                  shrink: true,
                  style: {
                    color: colors.lightText,
                    fontWeight: '500'
                  }
                }}
                InputProps={{
                  style: {
                    fontSize: '16px',
                    backgroundColor: '#fff',
                    borderRadius: '12px'
                  }
                }}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: '#e2e8f0',
                    },
                    '&:hover fieldset': {
                      borderColor: colors.accent,
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: colors.primary,
                      borderWidth: '2px'
                    },
                  }
                }}
              />
            </Box>
            
            <Box mt={3} p={3} bgcolor={colors.highlight} borderRadius="12px">
              <Typography variant="subtitle1" style={{ 
                fontWeight: '600',
                color: colors.primary,
                marginBottom: '12px'
              }}>
                Summary of Inputs
              </Typography>
              <Box display="grid" gridTemplateColumns={isMobile ? "1fr" : "repeat(2, 1fr)"} gap={1.5}>
                {inputFields.map((field, index) => (
                  <Box key={index}>
                    <Typography variant="body2" style={{ 
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <span style={{ color: colors.text, fontWeight: '500' }}>{field.label}:</span> 
                      <span style={{ 
                        color: inputs[field.name] ? colors.primary : colors.lightText,
                        fontWeight: '600'
                      }}>
                        {inputs[field.name] ? `₹${Number(inputs[field.name]).toLocaleString('en-IN')}` : 'Not entered'}
                      </span>
                    </Typography>
                  </Box>
                ))}
              </Box>
            </Box>
            
            <Box mt={4} display="flex" justifyContent="center" gap={2}>
              <SecondaryButton 
                onClick={handleClear}
                disabled={loading}
              >
                Clear
              </SecondaryButton>
              <PrimaryButton 
                onClick={calculateTax}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <CircularProgress size={24} style={{ color: '#fff', marginRight: '8px' }} />
                    Calculating...
                  </>
                ) : 'Calculate Tax'}
              </PrimaryButton>
            </Box>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Box mt={3}>
                  <Alert 
                    severity="error" 
                    onClose={() => setError(null)}
                    sx={{
                      borderRadius: '12px',
                      borderLeft: `4px solid ${colors.error}`
                    }}
                  >
                    {error}
                  </Alert>
                </Box>
              </motion.div>
            )}
          </Box>
        </StyledPaper>
      </motion.div>

      {/* Right Panel - Results */}
      <motion.div
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.1 }}
        style={{ 
          width: isMobile ? '100%' : '30%',
          flexShrink: 0
        }}
      >
        <StyledPaper elevation={0}>
          <Box p={isMobile ? 2 : 3}>
            {loading ? (
              <Box 
                display="flex" 
                flexDirection="column"
                alignItems="center" 
                justifyContent="center" 
                height="300px"
                gap={2}
              >
                <CircularProgress size={60} thickness={4} style={{ color: colors.primary }} />
                <Typography variant="body1" style={{ 
                  color: colors.primary,
                  fontWeight: '500'
                }}>
                  Calculating your tax savings...
                </Typography>
              </Box>
            ) : results ? (
              <>
                <Typography variant="h5" style={{ 
                  color: colors.primary,
                  fontWeight: '700',
                  marginBottom: '24px',
                  letterSpacing: '-0.5px'
                }}>
                  Tax Results
                </Typography>
                
                <Box mb={4}>
                  <Typography variant="h6" style={{ 
                    color: colors.text,
                    fontWeight: '600',
                    marginBottom: '16px'
                  }}>
                    Regime Comparison
                  </Typography>
                  
                  <Box mb={3}>
                    <motion.div
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <Box 
                        p={3}
                        bgcolor={results.suggestion === 'OLD' ? colors.highlight : '#ffffff'}
                        border={results.suggestion === 'OLD' ? `2px solid ${colors.primary}` : '1px solid #e2e8f0'}
                        borderRadius="12px"
                        textAlign="center"
                        sx={results.suggestion === 'OLD' ? {
                          animation: `${pulse} 2s ease-in-out infinite`,
                        } : {}}
                      >
                        <Typography style={{ 
                          fontWeight: '600',
                          color: colors.text
                        }}>
                          Old Regime
                        </Typography>
                        <Typography variant="h4" style={{ 
                          margin: '12px 0',
                          fontWeight: '700',
                          color: colors.primary
                        }}>
                          ₹{results.oldRegime.totalTaxWithCess.toLocaleString('en-IN')}
                        </Typography>
                        <SecondaryButton 
                          size="small"
                          onClick={() => handleOpenBreakup(results.oldRegime)}
                          style={{
                            marginTop: '8px',
                            minWidth: '120px'
                          }}
                        >
                          View Details
                        </SecondaryButton>
                      </Box>
                    </motion.div>
                  </Box>
                  
                  <Box mb={3}>
                    <motion.div
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <Box 
                        p={3}
                        bgcolor={results.suggestion === 'NEW' ? colors.highlight : '#ffffff'}
                        border={results.suggestion === 'NEW' ? `2px solid ${colors.primary}` : '1px solid #e2e8f0'}
                        borderRadius="12px"
                        textAlign="center"
                        sx={results.suggestion === 'NEW' ? {
                          animation: `${pulse} 2s ease-in-out infinite`,
                        } : {}}
                      >
                        <Typography style={{ 
                          fontWeight: '600',
                          color: colors.text
                        }}>
                          New Regime
                        </Typography>
                        <Typography variant="h4" style={{ 
                          margin: '12px 0',
                          fontWeight: '700',
                          color: colors.primary
                        }}>
                          ₹{results.newRegime.totalTaxWithCess.toLocaleString('en-IN')}
                        </Typography>
                        <SecondaryButton 
                          size="small"
                          onClick={() => handleOpenBreakup(results.newRegime)}
                          style={{
                            marginTop: '8px',
                            minWidth: '120px'
                          }}
                        >
                          View Details
                        </SecondaryButton>
                      </Box>
                    </motion.div>
                  </Box>
                  
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.4 }}
                  >
                    <Box 
                      p={3} 
                      bgcolor={colors.highlight} 
                      borderRadius="12px"
                      textAlign="center"
                    >
                      <Typography variant="h6" style={{ 
                        color: colors.primary,
                        fontWeight: '700',
                        marginBottom: '8px'
                      }}>
                        You save ₹{results.savings.toLocaleString('en-IN')}
                      </Typography>
                      <Typography style={{ fontWeight: '500' }}>
                        <strong>Recommendation:</strong> The{' '}
                        <span style={{ 
                          color: colors.primary,
                          fontWeight: '600',
                          textTransform: 'capitalize'
                        }}>
                          {results.suggestion.toLowerCase()}
                        </span>{' '}
                        regime is better for you
                      </Typography>
                    </Box>
                  </motion.div>
                </Box>
              </>
            ) : (
              <Box 
                display="flex" 
                flexDirection="column"
                alignItems="center" 
                justifyContent="center" 
                height="300px"
                textAlign="center"
                p={3}
              >
                <img 
                  src="https://cdn-icons-png.flaticon.com/512/3132/3132693.png" 
                  alt="Tax illustration" 
                  width="120" 
                  style={{ opacity: 0.6, marginBottom: '16px' }}
                />
                <Typography variant="body1" style={{ 
                  color: colors.lightText,
                  maxWidth: '300px'
                }}>
                  Enter your salary details and click "Calculate Tax" to see your tax savings comparison
                </Typography>
              </Box>
            )}
          </Box>
        </StyledPaper>
      </motion.div>

      {/* Tax Breakup Dialog */}
      <Dialog
        open={openBreakup}
        onClose={handleCloseBreakup}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: '16px',
            overflow: 'hidden'
          }
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <DialogTitle sx={{ 
            backgroundColor: colors.primary,
            color: 'white',
            padding: '16px 24px'
          }}>
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Typography variant="h6" sx={{ fontWeight: '600' }}>
                Detailed Tax Breakup - {selectedRegime === results?.oldRegime ? 'Old Regime' : 'New Regime'}
              </Typography>
              <IconButton 
                onClick={handleCloseBreakup}
                sx={{ color: 'white' }}
              >
                <CloseIcon />
              </IconButton>
            </Box>
          </DialogTitle>
          <DialogContent dividers sx={{ padding: 0 }}>
            {selectedRegime && (
              <Box>
                <Box p={3}>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle1" sx={{ 
                        fontWeight: '600',
                        color: colors.primary,
                        mb: 1
                      }}>
                        Income Summary
                      </Typography>
                      <TableContainer>
                        <Table size="small">
                          <TableBody>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Total Earnings</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.grossIncome.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Total Exemptions</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.totalDeductions.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow sx={{ backgroundColor: colors.highlight }}>
                              <TableCell sx={{ fontWeight: '600' }}>Taxable Income</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '700' }}>
                                ₹{selectedRegime.taxableIncome.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Typography variant="subtitle1" sx={{ 
                        fontWeight: '600',
                        color: colors.primary,
                        mb: 1
                      }}>
                        Tax Calculation
                      </Typography>
                      <TableContainer>
                        <Table size="small">
                          <TableBody>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Rebate u/s 87A</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.rebate.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Surcharge</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.surchargeIncome.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Tax + Surcharge</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.taxIncludingSurchargeIncome.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow>
                              <TableCell sx={{ fontWeight: '500' }}>Education Cess</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '600' }}>
                                ₹{selectedRegime.cess.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                            <TableRow sx={{ backgroundColor: colors.highlight }}>
                              <TableCell sx={{ fontWeight: '600' }}>Total Tax Liability</TableCell>
                              <TableCell align="right" sx={{ fontWeight: '700' }}>
                                ₹{selectedRegime.totalTaxWithCess.toLocaleString('en-IN')}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Grid>
                  </Grid>
                </Box>
                
                <Box p={3} sx={{ backgroundColor: '#f8fafb' }}>
                  <Typography variant="subtitle1" sx={{ 
                    fontWeight: '600',
                    color: colors.primary,
                    mb: 2
                  }}>
                    Tax Slab Rates
                  </Typography>
                  <TableContainer component={Paper} sx={{ borderRadius: '12px', overflow: 'hidden' }}>
                    <Table>
                      <TableHead sx={{ backgroundColor: colors.highlight }}>
                        <TableRow>
                          <TableCell sx={{ fontWeight: '600' }}>Income Range</TableCell>
                          <TableCell align="right" sx={{ fontWeight: '600' }}>Tax Rate</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {selectedRegime.taxSlabs.map((slab, index) => (
                          <TableRow 
                            key={index}
                            hover
                            sx={{ 
                              '&:nth-of-type(odd)': { backgroundColor: '#ffffff' },
                              '&:nth-of-type(even)': { backgroundColor: colors.highlight }
                            }}
                          >
                            <TableCell>{slab.range}</TableCell>
                            <TableCell align="right">{slab.tax}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              </Box>
            )}
          </DialogContent>
          <DialogActions sx={{ padding: '16px 24px' }}>
            <SecondaryButton onClick={handleCloseBreakup}>
              Close
            </SecondaryButton>
          </DialogActions>
        </motion.div>
      </Dialog>
    </motion.div>
  );
};

export default IncomeTaxCalculator;